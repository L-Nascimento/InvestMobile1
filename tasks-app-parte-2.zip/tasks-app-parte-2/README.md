# Tasks App

```bash
npm install
```

```bash
npm start
```
